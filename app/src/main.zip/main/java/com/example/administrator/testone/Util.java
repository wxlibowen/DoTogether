package com.example.administrator.testone;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

public class Util {
    private static Context context;
    private static void getContext(){
        if (context==null){
            context=MyApplication.getContext();
        }

    }


    /**
     * 获取当前app版本号
     * @return
     * @throws PackageManager.NameNotFoundException
     */
    public static int getVersionCode() throws PackageManager.NameNotFoundException {
        getContext();
        PackageManager manager=context.getPackageManager();
        PackageInfo info=manager.getPackageInfo(context.getPackageName(),0);
        return  info.versionCode;
    }







}
